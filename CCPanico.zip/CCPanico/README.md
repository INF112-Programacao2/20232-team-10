# 20232-team-10
20232-team-10

Para compilacao em terminals de Linux com SFML-TGUI ja instalado:

g++ main.cpp -ltgui -lsfml-graphics -lsfml-window -lsfml-system -lsfml-audio actions.cpp actor.cpp dice.cpp engine.cpp fight.cpp place.cpp player.cpp

Na execucao do makefile (digitando "make" no terminal do diretorio da pasta CCPanico", um executavel "main" vai ser gerado.
