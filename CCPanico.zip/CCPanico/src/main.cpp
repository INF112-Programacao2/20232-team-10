#include "../include/engine.h"

int main(){
    Engine engine;
    engine.main_menu();
    engine.quit_game();
}
